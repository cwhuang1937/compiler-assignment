var v1 int32 = 400
var v2 int32 = 700

// using if statement
if v1 == 400 {

	// if condition is true then
	// check the following
	if v2 <= 600 {
		print("OuO\n")
	} else if v2 == 700 {

		// if condition is true
		// then display the following
		print("Value of v1 is 400 and v2 is 700")
	} else {
		print("QuQ\n")
	}
}