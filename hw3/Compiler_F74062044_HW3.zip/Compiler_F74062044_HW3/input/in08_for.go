var x int32 = 0
x += 10
for x > 0 {
	println(x)
	x--
}