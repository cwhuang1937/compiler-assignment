for x > 0 {
    x--
}

for i = 0; i < 10; i++ {
	count++
} 