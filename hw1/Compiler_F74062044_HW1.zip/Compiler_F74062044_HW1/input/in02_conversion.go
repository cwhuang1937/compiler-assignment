a = int32(f)
f2 = float32(88)