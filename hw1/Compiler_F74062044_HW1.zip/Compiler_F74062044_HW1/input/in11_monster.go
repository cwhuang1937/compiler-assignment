var x int32 = 9
var y int32 = -87
var z int32 = 23
var _f_123 float32 = -212.3
var a int32 = int32(_f_123)
var b int32
if x < a {
	x++
} else if x < b {
	print(x <= z || x <= (y-z) && !(y <= z))
} else {
	x--
	if x > a && x < b {
		x++
	} else if x > b {
		x--
	}
	print(x)
	{
		var gggggggggggg float32
		gggggggggggg += float32(x)
		println(gggggggggggg < 3.0)
		var TRUE bool = false
		if !TRUE {
			var STRING string = "string"
			println(STRING)
		}
	}
	/*OuO
	Construct a compiler is very fun.

	NULL
	NEWLINE
	x -= 1000
	\n
	%^#&!#&@%&^%#&*@%
	*/x++ // Increase x /* after comment */
	/* */ /*
		*/ /* */

	for x > 0 {
		x += (9*-8)/a + 3 - (100 % 7)
		x %= 4
		println(x + 3)
	}
	println("Finish")
}