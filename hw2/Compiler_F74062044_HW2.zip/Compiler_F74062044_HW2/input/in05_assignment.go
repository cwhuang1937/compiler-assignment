var x int32
x = 1
x += 2
x -= 3
x *= 4
x /= 5
x %= 6

var yy float32 = 3.14
yy = 1.0
yy += 2.0
yy -= 3.0
yy *= 4.0
yy /= 5.0

var s string
s = "Hello"

var bbb bool = false
bbb = true

println(x)
println(yy)
println(s)
println(bbb)