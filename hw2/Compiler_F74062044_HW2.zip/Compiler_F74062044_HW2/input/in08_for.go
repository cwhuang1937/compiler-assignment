var x int32 = 0
x += 10
for x > 0 {
	println(x)
	x--
}

var i int32
for i = 0; i < 10; i++ {
	println(i)
}