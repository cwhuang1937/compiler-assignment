var height int32 = 99
{
    var width float32 = 3.14
}
var length float32
{
    var length string = "hello world"
    {
        var length bool  = true
    }
    var width string = "Hi, OuO\n"
}