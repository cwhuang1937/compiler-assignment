var x int32

var z float32
var x int32
y = 8
8 += x

var z int32

if gg > 0 {
	println("gg")
}